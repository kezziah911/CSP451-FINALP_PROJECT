module.exports = async function (context, myTimer) {
  const invBase  = 'http://4.239.101.178:5001';
  const prodBase = 'http://4.239.101.178:5002';
  const apiKey   = 'dev-key-123';

  const headers = { 'x-api-key': apiKey };

  async function check(base) {
    const url = `${base}/health`;
    context.log('[timer] calling', url);
    try {
      const res = await fetch(url, { headers });
      const text = await res.text();
      return { ok: res.ok, status: res.status, text };
    } catch (e) {
      return { ok: false, error: String(e) };
    }
  }

  const inv  = await check(invBase);
  const prod = await check(prodBase);

  context.log('[timer] result', { inv, prod });
  context.res = { status: 200, jsonBody: { inv, prod } };
};
